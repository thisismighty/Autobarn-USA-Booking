<?php

require 'bin/required.php';
require 'etc/steps-conf.php';

$CDV=new ControllerDefaultValues();
$_SESSION=$CDV->step2($_SESSION,$_POST);
$DUSP=new DataUSP();

?><!DOCTYPE>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=0.8, maximum-scale=0.8, user-scalable=0"/>
		<script type="text/javascript">
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-2588665-<?php echo $CDV->anal($_SESSION['referrer'])?>', 'auto', {allowLinker: true});
ga('require', 'linker');
ga('linker:autoLink', ['travellers-autobarn.com.au', 'travellers-autobarn.fr', 'travellers-autobarn.it', 'travellers-autobarn.de', 'travellers-autobarn.nl'], false, true);
ga('send', 'pageview');
		</script>
<?php echo ViewCSS::draw('bootstrap.min.css');?>
		<?php echo ViewCSS::draw('font-awesome.min.css');?>
		<?php echo ViewCSS::draw('body.css');?>
		<?php echo ViewCSS::draw('nav.css');?>
		<?php echo ViewCSS::draw('jquery-ui.css');?>
		<?php echo ViewCSS::draw('step2.css');?>
		<?php echo ViewCSS::draw('style-v7.css');?>
		<?php echo ViewJS::draw('jquery-2.1.3.min.js');?>
		<?php echo ViewJS::draw('jquery-ui.min.js');?>
		<?php echo ViewJS::draw('bootstrap.min.js');?>
		<?php echo ViewJS::draw('Template.js');?>
		<?php echo ViewJS::draw('Select.js');?>
		<?php echo ViewJS::draw('Log.js');?>
		<?php echo ViewJS::draw('View.js');?>
		<?php echo ViewJS::draw('Controller.js');?>
		<script src="<?php echo ControllerSourceSite::api_url_get()?>" type="text/javascript"></script>
		<?php echo ViewJS::draw('Step2.js');?>
		<?php echo ViewJS::draw('Step2View.js');?>
		<script type="text/javascript">
			Step2.data=<?php echo json_encode($_SESSION)?>;
			Step2.data.usp=<?php echo json_encode($DUSP->get())?>;
			View.media_queries=<?php echo json_encode(ViewCSS::media_queries())?>;
			$(function(){
				/* $("#PickupDate").datepicker({dateFormat:'dd/mm/yy',changeYear:true}); */
				/* $("#ReturnDate").datepicker({dateFormat:'dd/mm/yy',changeYear:true}); */
				
				var dateToday = new Date(); 
				$("input[name=PickupDate]").datepicker({
					numberOfMonths: 1,
					inline: true,
					minDate: dateToday,
					dateFormat: "dd/mm/yy",
					onSelect: function(selected) {
					  $("input[name=ReturnDate]").datepicker("option","minDate", selected)
					}
				});
				$("input[name=ReturnDate]").datepicker({ 
					numberOfMonths: 1,
					inline: true,
					minDate: dateToday,
					dateFormat: "dd/mm/yy",
					onSelect: function(selected) {
					   $("input[name=PickupDate]").datepicker("option","maxDate", selected)
					}
				});
			});
			$(function(){
				$('a.modify').on('click', function(){
					$('#search-form').slideDown(400);
					$("html, body").animate({ scrollTop: $('#search-form').offset().top }, 1000);
					return false;
				});
				$('#search-form .close').on('click', function(){
					$('#search-form').slideUp(400);
				});
				
			});

		</script>
        <?php echo $CDV->remarketing_code(); ?>
	</head>
	<body>
		<?php echo Template::header(ViewNav::step2())?>
		<main>
			<div class="container">
						 
		 
		   
				<article>
					<form id="search-form" method="post" action="step3.php" style="display:none;">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<h2>Modify Your Search
								<a class="close">Close <i class="fa fa-remove"></i></a>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="form-group row">
									<label for="PickupLocationID" class="col-sm-4 col-form-label">Pick up location*</label>
		   
									<div class="col-sm-8">
										<select name="PickupLocationID" id="PickupLocationID">
											<option value="<?php echo htmlspecialchars($_SESSION['PickupLocationID'])?>">Loading...</option>
										</select>
									</div>
								</div>
								
								<div class="form-group row">
									<label for="DropOffLocationID" class="col-sm-4 col-form-label">Return location*</label>
									<div class="col-sm-8">
										<select name="DropOffLocationID" id="DropOffLocationID">
											<option value="<?php echo htmlspecialchars($_SESSION['DropOffLocationID'])?>">Loading...</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">								
								
								<div class="row">
									<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<label for="PickupDate" class="col-sm-6 col-form-label">Date & time:</label>
											<div class="col-sm-6">
												<input type="text" name="PickupDate" id="PickupDate" value="<?php echo htmlspecialchars($_SESSION['PickupDate'])?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
										<div class="form-group row">
		   
											<div class="col-sm-12">
												<select id="PickupTime" name="PickupTime">
													<option value="<?php echo htmlspecialchars($_SESSION['PickupTime'])?>">Time</option>
													<option value="01:00:00">01:00</option>
													<option value="02:00:00">02:00</option>
													<option value="03:00:00">03:00</option>
													<option value="04:00:00">04:00</option>
													<option value="05:00:00">05:00</option>
													<option value="06:00:00">06:00</option>
													<option value="07:00:00">07:00</option>
													<option value="08:00:00">08:00</option>
													<option value="09:00:00">09:00</option>
													<option value="10:00:00">10:00</option>
													<option value="11:00:00">11:00</option>
													<option value="12:00:00">12:00</option>
													<option value="13:00:00">13:00</option>
													<option value="14:00:00">14:00</option>
													<option value="15:00:00">15:00</option>
													<option value="16:00:00">16:00</option>
													<option value="17:00:00">17:00</option>
													<option value="18:00:00">18:00</option>
													<option value="19:00:00">19:00</option>
													<option value="20:00:00">20:00</option>
													<option value="21:00:00">21:00</option>
													<option value="22:00:00">22:00</option>
													<option value="23:00:00">23:00</option>
													<option value="24:00:00">24:00</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<label for="ReturnDate" class="col-sm-6 col-form-label">Date & time:</label>
		   
											<div class="col-sm-6">
												<input type="text" name="ReturnDate" id="ReturnDate" value="<?php echo htmlspecialchars($_SESSION['ReturnDate'])?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<div class="col-sm-12">
												<select id="ReturnTime" name="ReturnTime">
													<option value="<?php echo htmlspecialchars($_SESSION['ReturnTime'])?>">Time</option>
													<option value="01:00:00">01:00</option>
													<option value="02:00:00">02:00</option>
													<option value="03:00:00">03:00</option>
													<option value="04:00:00">04:00</option>
													<option value="05:00:00">05:00</option>
													<option value="06:00:00">06:00</option>
													<option value="07:00:00">07:00</option>
													<option value="08:00:00">08:00</option>
													<option value="09:00:00">09:00</option>
													<option value="10:00:00">10:00</option>
													<option value="11:00:00">11:00</option>
													<option value="12:00:00">12:00</option>
													<option value="13:00:00">13:00</option>
													<option value="14:00:00">14:00</option>
													<option value="15:00:00">15:00</option>
													<option value="16:00:00">16:00</option>
													<option value="17:00:00">17:00</option>
													<option value="18:00:00">18:00</option>
													<option value="19:00:00">19:00</option>
													<option value="20:00:00">20:00</option>
													<option value="21:00:00">21:00</option>
													<option value="22:00:00">22:00</option>
													<option value="23:00:00">23:00</option>
													<option value="24:00:00">24:00</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group row">
											<label for="DriverAge" class="col-sm-5 col-form-label">Driver's age</label>
											<div class="col-sm-7">
												<select name="DriverAge" id="DriverAge">
                                                    <option value="21">21 + min</option>
													<option value="21+">21+</option>
													<option value="25+">25+</option>
													<option value="30+">30+</option>
													<option value="25+">35+</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
										<div class="form-group row">
											<label for="PromoCode" class="col-sm-6 col-form-label">Promotional Code:</label>
											<div class="col-sm-6">
												<input type="text" name="PromoCode" id="PromoCode" value="<?php echo $_SESSION['PromoCode'];?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="row">
											<div class="col-lg-12 col-md-12s col-sm-12 col-xs-12">
												<div id="update-search" class="btn btn-default" onclick="Step2.controller.start_live()">
													<img src="image/preview-full-loading.gif" style="visibility:hidden;" />
													<span class="">UPDATE SEARCH</span>
													<img src="image/preview-full-loading.gif" />
												</div>
												<div id="change-search" class="btn btn-default" onclick="Step2.controller.change_search()" style="display:none;">
													CHANGE SEARCH
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
							<input type="hidden" name="Vehiclecategoryid" value=""/>
							<input type="hidden" name="PickupLocation_name" value=""/>
							<input type="hidden" name="DropOffLocation_name" value=""/>
							<input type="hidden" name="CategoryType_name" value=""/>
							<input type="hidden" name="CategoryType_vehicledescriptionurl" value=""/>
							<input type="hidden" name="CategoryType_imageurl" value=""/>
							<input type="hidden" name="price_table_html" value=""/>						
						</div>
					</form>
					<div id="form-error" style="display:none"></div>
				</article>
				
				<aside>
					<script type="text/html" id="peoplegraphic_one_html">
						<div class="adult"><img src="image/adult.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">%no</span></div>
						
					</script>

					<script type="text/html" id="peoplegraphic_html">
						<div class="adult"><img src="image/adult.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">%noadults</span></div>
						<div class="child"><img src="image/child.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">%nochildrens</span></div>
										
					</script>
					<script type="text/html" id="car_html">
						<div class="vechicle">
						<div class="row">
								<div class="vehicle-linfo col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div class="pic">
								<img src="%imageurl" alt="%categoryfriendlydescription" title="%categoryfriendlydescription"/>
							</div>
                            <div class="features">
                            %peoplegraphic
									<!--	
										<div class="big-case"><img src="image/big-case.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="small-case"><img src="image/small-case.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>								
									--></div>
									<div class="more">
									<a href="javascript:void(0);"
									onclick="window.open('%vehicledescriptionurl','Car','width=600,height=800,menu=no,toolbar=no,scrollbars=yes,status=no');return false;"
									title="Click here for detailed description">Vehicle Information</a>
								%mostpopular
									</div>							
								</div>
						<div class="vehicle-rinfo col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<h3 class="title">%categoryfriendlydescription</h3>
									<span class="rental-days">%numberofdays Rental Days</span><span class="rate">Daily Rate $%avgrate </span>
									<span class="feature">Free Extra Drivers (max. 4) @ $0.00 p/day</span>
									<span class="feature">Free sleeping gear @ $0.00 p/day</span>
									<span class="feature">Free cooking equipment and chairs @ $0.00</span>
									%totaldiscount_html
										%freedays_html
										%relocfee_html
										%unattendedfee_html
										%afterhourfee_html
										%mandatoryfee_html
									<div class="pricing">
										<span class="curr-symbol">$</span><span class="price-num">%total</span><span class="curr-text">USD</span>
										<span class="tax">Exludes sales tax</span>
									</div>
									%book_html
							<!--		<a class="btn btn-default btn-select">BOOK NOW</a>-->
								</div>
						<!--
							<div class="carDetails">
								<div class="tb">
									<div class="tb-row">
										<div class="info">
											<a href="javascript:void(0);"
												onclick="window.open('%vehicledescurl','Car','width=600,height=800,menu=no,toolbar=no,scrollbars=yes,status=no');return false;"
												target="_blank" title="Click here for detailed description">
												<img src="image/info.png" alt="info"/>
											</a>
										</div>
										<div class="cartitle">
											<h2><span class="main">%categoryfriendlydescription</span></h2>
											%peoplegraphic
										</div>
									</div>
								</div>
								<div class='unlimited'>%usp</div>
								<div>
									<table style="display:none;" class="details" cellspacing="0">
										<tr>
											<th>Product</th>
											<th>Rental Days</th>
											<th>Daily Rate</th>
											<th>Total</th>
										</tr>
										<tr>
											<td>Days</td>
											<td>%numofdays</td>
											<td>$%avgrate</td>
											<td>$%total</td>
										</tr>
										%totaldiscount_html
										%freedays_html
										%relocfee_html
										%unattendedfee_html
										%afterhourfee_html
										%mandatoryfee_html
										<tr class="total">
											<td>Total Price</td>
											<td></td>
											<td></td>
											<td>$%price_total</td>
										</tr>
									</table>
								</div>
							</div>
							<div class="carAvaliability">
								<div class="carAvaliabilityText">
									%book_html
								</div>
							</div>
					-->
					</div>
					</div>
					</script>
					<script type="text/html" id="search_content_html">
					<span class="title">Pickup Location:</span> <span class="val">%pickupLocation</span>
								<span class="title">Pickup Date & Time:</span> <span class="val">%pickupDate</span>
								<span class="title">Return Location:</span> <span class="val">%returnLocation</span>
								<span class="title">Return Date & Time:</span> <span class="val">%returnDate</span>
								<span class="title">Youngest Driver:</span> <span class="val">%DriverAge</span>
					</script>
					<script type="text/html" id="totaldiscount_html">
						<tr>
							<td class="totaldiscount">Discounts</td>
							<td></td>
							<td></td>
							<td>-$%totaldiscount</td>
						</tr>
					</script>
					<script type="text/html" id="freedays_html">
						<tr>
							<td class="freedays" colspan="4">You qualify for <span>%freedays</span> Free day(s) special</td>
						</tr>
					</script>
					<script type="text/html" id="relocfee_html">
						<tr>
							<td class="relocfee">Relocation Fee</td>
							<td></td>
							<td></td>
							<td>$%relocfee</td>
						</tr>
					</script>
					<script type="text/html" id="unattendedfee_html">
						<tr>
							<td class="unattendedfee">Unattended Return Fee for 
								<span class="location">%location</span></td>
							<td></td>
							<td></td>
							<td>$%unattendedfee</td>
						</tr>
					</script>
					<script type="text/html" id="afterhourfee_html">
						<tr>
							<td class="afterhourfee">Afterhour Fee for 
								<span class="location">%location</span></td>
							<td></td>
							<td></td>
							<td>$%afterhourfee</td>
						</tr>
					</script>
					<script type="text/html" id="mandatoryfee_daily_html">
						<tr class="mandatoryfee_daily">
							<td>%name</td>
							<td>%numofdays</td>
							<td>$%per_day</td>
							<td>$%total</td>
						</tr>
					</script>
					<script type="text/html" id="mandatoryfee_percentage_html">
						<tr class="mandatoryfee_percentage">
							<td>%name</td>
							<td></td>
							<td></td>
							<td>$%fees</td>
						</tr>
					</script>
					<script type="text/html" id="mandatoryfee_unknown_html">
						<tr class="mandatoryfee_unknown" rel="%type">
							<td>%name</td>
							<td></td>
							<td></td>
							<td>$%fees</td>
						</tr>
					</script>
					<script type="text/html" id="booked_out_html">
						<div class="booked_out">BOOKED OUT</div>
					</script>
					<script type="text/html" id="book_now_html">
						<a class="btn btn-default btn-select"
									href="javascript:void(0)"
									onclick="Step2.controller.book_now(
										%vehiclecategoryid,'%categorytype_name','%categorytype_vehicledescriptionurl','%categorytype_imageurl',this
									)">SELECT</a>

					</script>
					<script type="text/html" id="request_now_html">
					
							<a class="btn btn-default btn-select"
									href="javascript:void(0)"
									onclick="Step2.controller.book_now(
										%vehiclecategoryid,'%categorytype_name','%categorytype_vehicledescriptionurl','%categorytype_imageurl',this
									)">BOOK NOW</a>
							
					</script>					
				</aside>
			
													
		
				<div class="row">
					
					<div id="result" class="content col-lg-8 col-md-8 col-sm-12 col-xs-12">
						<div class="vechicle">
							<div class="row">
								<div class="vehicle-linfo col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="pic">
										<img src="image/car1.png" />
									</div>
									<div class="features">
										<div class="adult"><img src="image/adult.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="child"><img src="image/child.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="big-case"><img src="image/big-case.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="small-case"><img src="image/small-case.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
									</div>
									<div class="more">
										<a href="#">Vehicle Information</a>
									</div>
								</div>
								<div class="vehicle-rinfo col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<h3 class="title">Ventura</h3>
									<span class="rental-days">13 Rental Days</span><span class="rate">Daily Rate $89.62</span>
									<span class="feature">Free Extra Drivers (max. 4) @ $0.00 p/day</span>
									<span class="feature">Free sleeping gear @ $0.00 p/day</span>
									<span class="feature">Free cooking equipment and chairs @ $0.00</span>
									<div class="pricing">
										<span class="curr-symbol">$</span><span class="price-num">846</span><span class="small">.00</span><span class="curr-text">USD</span>
											   
						  
							   
		   
										<span class="tax">Exludes sales tax</span>
									</div>
									<a class="btn btn-default btn-select">Select</a>
								</div>
							</div>
						</div>
						<div class="vechicle">
							<div class="row">
								<div class="vehicle-linfo col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="pic">
										<img src="image/car2.png" />
									</div>
									<div class="features">
										<div class="adult"><img src="image/adult.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="child"><img src="image/child.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="big-case"><img src="image/big-case.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>
										<div class="small-case"><img src="image/small-case.png"> <span class="multi"><i class="fa fa-remove"></i></span> <span class="num">3</span></div>								
									</div>
									<div class="more">
										<a href="#">Vehicle Information</a>
																												   
					
									</div>
								</div>
								<div class="vehicle-rinfo col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<h3 class="title">Maverick</h3>
									<span class="rental-days">13 Rental Days</span><span class="rate">Daily Rate $89.62</span>
									<span class="feature">Free Extra Drivers (max. 4) @ $0.00 p/day</span>
									<span class="feature">Free sleeping gear @ $0.00 p/day</span>
									<span class="feature">Free cooking equipment and chairs @ $0.00</span>
									<div class="pricing">
										<span class="curr-symbol">$</span><span class="price-num">846</span><span class="small">.00</span><span class="curr-text">USD</span>
										<span class="tax">Exludes sales tax</span>
									</div>
									<a class="btn btn-default btn-select">Select</a>
								</div>
							</div>
						</div>
					</div>
					
					<div id="sidebar" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
						<div id="itinerary" class="widget">
							<div class="widget-head">
								<h3>Your Itinerary</h3>
								<a href="#" class="modify">Modify Search</a>
							</div>
							<div class="widget-content" id="search_content">
								
							</div>
						</div>
																												   
											  
					</div>					
				</div>
			</div>
						  
		</main>
		
		<?//=Template::footer()?>
		
	</body>
</html>
