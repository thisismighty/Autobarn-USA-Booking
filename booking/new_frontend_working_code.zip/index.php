<?php
header('Location: step2.php');
die();
