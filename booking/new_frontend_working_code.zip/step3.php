<?php
require 'bin/required.php';
require 'etc/steps-conf.php';

$CDV = new ControllerDefaultValues();
$_SESSION = $CDV->step4($_SESSION, $_POST);
$DS4 = new DataStep4();
$DUSP=new DataUSP();

?><!DOCTYPE>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=0.8, maximum-scale=0.8, user-scalable=0"/>
		<script type="text/javascript">
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-2588665-<?php echo $CDV->anal($_SESSION['referrer'])?>', 'auto', {allowLinker: true});
			ga('require', 'linker');
			ga('linker:autoLink', ['travellers-autobarn.com.au', 'travellers-autobarn.fr', 'travellers-autobarn.it', 'travellers-autobarn.de', 'travellers-autobarn.nl'], false, true);
			ga('send', 'pageview');			
		</script>
		<?php echo ViewCSS::draw('bootstrap.min.css');?>
		<?php echo ViewCSS::draw('font-awesome.min.css');?>
		<?php echo  ViewCSS::draw('body.css'); ?>
		<?php echo  ViewCSS::draw('nav.css'); ?>
		<?php echo  ViewCSS::draw('jquery-ui.css'); ?>
		<?php echo  ViewCSS::draw('step4.css'); ?>
		<?php echo ViewCSS::draw('style-v7.css');?>
		<?php echo  ViewJS::draw('jquery-2.1.3.min.js'); ?>
		<?php echo  ViewJS::draw('jquery-ui.min.js'); ?>
		<?php echo ViewJS::draw('bootstrap.min.js');?>
		<?php echo  ViewJS::draw('Template.js'); ?>
		<?php echo  ViewJS::draw('Select.js'); ?>
		<?php echo  ViewJS::draw('Date.js'); ?>
		<?php echo  ViewJS::draw('Log.js'); ?>
		<?php echo  ViewJS::draw('View.js'); ?>
		<?php echo  ViewJS::draw('Controller.js'); ?>
		<script src="<?php echo  ControllerSourceSite::api_url_get() ?>" type="text/javascript"></script>
		<? //= ViewJS::draw('Step4.js'); ?>
		<?php echo  ViewJS::draw('Step4Controller.js'); ?>
		<?php echo  ViewJS::draw('Step4View.js'); ?>
		<script type="text/javascript">
			// Step4.data =<?php echo  json_encode($_SESSION) ?>;
			// Step4.data.deposit_model='<?php echo $DS4->country()?>';
			<?php echo gethostname()=='fulvios-sandbox'?'Log.display=2;':''?>
			$(function(){
				$('a.modify').on('click', function(){
					$('#search-form').slideDown(400);
					$("html, body").animate({ scrollTop: $('#search-form').offset().top }, 1000);
					return false;
				});
				$('#search-form .close').on('click', function(){
					$('#search-form').slideUp(400);
				});
			});
			
			$(function(){
				$('a.modify').on('click', function(){
					$('#search-form').slideDown(400);
					return false;
				});
				$('#search-form .close').on('click', function(){
					$('#search-form').slideUp(400);
				});
			});
		</script>
		<?php echo $CDV->remarketing_code(); ?>
	</head>
	<body>
		<?php echo Template::header(ViewNav::step4())?>
		<main>
			<div class="container">
				<article>
					<form id="search-form" method="post" action="step3.php" style="display:none;">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<h2>Modify Your Search
								<a class="close">Close <i class="fa fa-remove"></i></a>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="form-group row">
									<label for="PickupLocationID" class="col-sm-4 col-form-label">Pick up location*</label>
									<div class="col-sm-8">
										<select name="PickupLocationID" id="PickupLocationID">
											<option value="<?php echo htmlspecialchars($_SESSION['PickupLocationID'])?>">Loading...</option>
										</select>
									</div>
								</div>
								
								<div class="form-group row">
									<label for="DropOffLocationID" class="col-sm-4 col-form-label">Return location*</label>
									<div class="col-sm-8">
										<select name="DropOffLocationID" id="DropOffLocationID">
											<option value="<?php echo htmlspecialchars($_SESSION['DropOffLocationID'])?>">Loading...</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">								
								
								<div class="row">
									<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<label for="PickupDate" class="col-sm-6 col-form-label">Date & time:</label>
											<div class="col-sm-6">
												<input type="text" name="PickupDate" id="PickupDate" value="<?php echo htmlspecialchars($_SESSION['PickupDate'])?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<div class="col-sm-12">
												<select id="PickupTime" name="PickupTime">
													<option value="<?php echo htmlspecialchars($_SESSION['PickupTime'])?>">Time</option>
													<option value="01:00:00">01:00</option>
													<option value="02:00:00">02:00</option>
													<option value="03:00:00">03:00</option>
													<option value="04:00:00">04:00</option>
													<option value="05:00:00">05:00</option>
													<option value="06:00:00">06:00</option>
													<option value="07:00:00">07:00</option>
													<option value="08:00:00">08:00</option>
													<option value="09:00:00">09:00</option>
													<option value="10:00:00">10:00</option>
													<option value="11:00:00">11:00</option>
													<option value="12:00:00">12:00</option>
													<option value="13:00:00">13:00</option>
													<option value="14:00:00">14:00</option>
													<option value="15:00:00">15:00</option>
													<option value="16:00:00">16:00</option>
													<option value="17:00:00">17:00</option>
													<option value="18:00:00">18:00</option>
													<option value="19:00:00">19:00</option>
													<option value="20:00:00">20:00</option>
													<option value="21:00:00">21:00</option>
													<option value="22:00:00">22:00</option>
													<option value="23:00:00">23:00</option>
													<option value="24:00:00">24:00</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<label for="ReturnDate" class="col-sm-6 col-form-label">Date & time:</label>
											<div class="col-sm-6">
												<input type="text" name="ReturnDate" id="ReturnDate" value="<?php echo htmlspecialchars($_SESSION['ReturnDate'])?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<div class="col-sm-12">
												<select id="ReturnTime" name="ReturnTime">
													<option value="<?php echo htmlspecialchars($_SESSION['ReturnTime'])?>">Time</option>
													<option value="01:00:00">01:00</option>
													<option value="02:00:00">02:00</option>
													<option value="03:00:00">03:00</option>
													<option value="04:00:00">04:00</option>
													<option value="05:00:00">05:00</option>
													<option value="06:00:00">06:00</option>
													<option value="07:00:00">07:00</option>
													<option value="08:00:00">08:00</option>
													<option value="09:00:00">09:00</option>
													<option value="10:00:00">10:00</option>
													<option value="11:00:00">11:00</option>
													<option value="12:00:00">12:00</option>
													<option value="13:00:00">13:00</option>
													<option value="14:00:00">14:00</option>
													<option value="15:00:00">15:00</option>
													<option value="16:00:00">16:00</option>
													<option value="17:00:00">17:00</option>
													<option value="18:00:00">18:00</option>
													<option value="19:00:00">19:00</option>
													<option value="20:00:00">20:00</option>
													<option value="21:00:00">21:00</option>
													<option value="22:00:00">22:00</option>
													<option value="23:00:00">23:00</option>
													<option value="24:00:00">24:00</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group row">
											<label for="DriverAge" class="col-sm-5 col-form-label">Driver's age</label>
											<div class="col-sm-7">
												<select name="DriverAge" id="DriverAge">
													<option value="">21 + min</option>
													<option value="">21+</option>
													<option value="">25+</option>
													<option value="">30+</option>
													<option value="">35+</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
										<div class="form-group row">
											<label for="PromotionalCode" class="col-sm-6 col-form-label">Promotional Code:</label>
											<div class="col-sm-6">
												<input type="text" name="PromotionalCode" id="PromotionalCode" value=""/>
											</div>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="row">
											<div class="col-lg-12 col-md-12s col-sm-12 col-xs-12">
												<div id="update-search" class="btn btn-default" onclick="Step2.controller.start_live()" style="display:none;">
													<img src="image/preview-full-loading.gif" style="visibility:hidden;" />
													<span class="">UPDATE SEARCH</span>
													<img src="image/preview-full-loading.gif" />
												</div>
												<div id="change-search" class="btn btn-default" onclick="Step2.controller.change_search()">
													CHANGE SEARCH
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
							<input type="hidden" name="CarSizeID" value=""/>
							<input type="hidden" name="PickupLocation_name" value=""/>
							<input type="hidden" name="DropOffLocation_name" value=""/>
							<input type="hidden" name="CategoryType_name" value=""/>
							<input type="hidden" name="CategoryType_vehicledescurl" value=""/>
							<input type="hidden" name="CategoryType_imagename" value=""/>
							<input type="hidden" name="price_table_html" value=""/>						
						</div>
					</form>
					<div id="form-error" style="display:none"></div>
				</article>
				<?php /*
				<article>
					<div id="car">
						<div class="car">
							<div class="image">
								<img
									class="main"
									src="<?php echo $_SESSION['CategoryType_imagename']?>"
									alt="<?php echo $_SESSION['CategoryType_name']?>"
									title="<?php echo $_SESSION['CategoryType_name']?>"/>
								<img src="/booking/image/most-popular-step2.png" class="most-popular" style="display:none" />
							</div>
							<div class="locationContainer">
								<div class="tb">
									<div class="tb-row">
										<div class="info">
											<a href="javascript:void(0);"
												onclick="window.open('<?php echo $_SESSION['CategoryType_vehicledescurl']?>','Car','width=600,height=800,menu=no,toolbar=no,scrollbars=yes,status=no');return false;"
												target="_blank"
												title="Click here for detailed description">
												<img src="image/info.png" alt="info"/>
											</a>
										</div>
										<div class="cartitle"></div>
									</div>
								</div>
								<div class="peoplegraphic">
									%peoplegraphic_html
									
								</div>
								<div class='unlimited'><?php echo $DUSP->get_one($_SESSION['CarSizeID'])?></div>
								<div id="price_details">
									<table style="display:none;" class="location" cellspacing="0">
										<tbody><tr>
											<th valign="top">Vehicle:</th>
											<td><?php echo $_SESSION['CategoryType_name']?></td>
										</tr>
										<tr>
											<th valign="top">Pickup Location:</th>
											<td><?php echo $_SESSION['PickupLocation_name']?></td>
										</tr>
										<tr>
											<th valign="top">Pickup Date &amp; Time:</th>
											<td><?php echo $_SESSION['PickupDate_formatted']?></td>
										</tr>
										<tr>
											<th valign="top">Return Location:</th>
											<td><?php echo $_SESSION['DropOffLocation_name']?></td>
										</tr>
										<tr>
											<th valign="top">Return Date &amp; Time:</th>
											<td><?php echo $_SESSION['ReturnDate_formatted']?></td>
										</tr>
										<tr>
											<th valign="top">Driver age:</th>
											<td>18 - 75</td>
										</tr>
									</tbody></table>
									<table style="display:none;" class="details" cellspacing="0">
									</table>
								</div>
							</div>
							<div>
								<div class="cartotal">
									<div>
										<div>
											<span>TOTAL</span>
											<span id="total-top"></span>
										</div>
									</div>
									<a class="show" href="javascript:void(0)" onclick="Step4.controller.price_details.show(this)">+ show booking details</a>
									<a style="display:none" class="hide" href="javascript:void(0)" onclick="Step4.controller.price_details.hide(this)">- hide booking details</a>
								</div>
							</div>
						</div>
					</div>
					<div id="form-error" style="display:none"></div>
					<form action="step5.php" method="post" id="frmStep4">
						<div class="customerdetails">
							<div id="customer_details">
								<h3>CUSTOMER DETAILS <span>(ALL FIELDS REQUIRED)</span></h3>
								<div class="customerinfo">
									<div>
										<div>
											<label for="firstname">First name:</label>
											<input type="text" name="firstname" id="firstname" value="<?php echo htmlspecialchars($_SESSION['firstname'])?>"/>
										</div>
										<div>
											<label for="lastname">Last name:</label>
											<input type="text" name="lastname" id="lastname" value="<?php echo htmlspecialchars($_SESSION['lastname'])?>"/>
										</div>
									</div>
									<div>
										<div>
											<label for="email">Email:</label>
											<input type="text" name="email" id="email" value="<?php echo htmlspecialchars($_SESSION['email'])?>"/>
										</div>
										<div>
											<label for="phone">Phone (incl. area code):</label>
											<input type="text" name="phone" id="phone" value="<?php echo htmlspecialchars($_SESSION['phone'])?>"/>
										</div>
									</div>
									<div>
										<div>
											<label for="notraveling">Number of people travelling:</label>
											<input type="text" name="notraveling" id="notraveling" value="<?php echo htmlspecialchars($_SESSION['notraveling'])?>"/>
										</div>
										<div>
											<label for="foundus">How did you hear about us:</label>
											<select id="foundus" name="foundus"></select>
										</div>
									</div>
								</div>
								<div>
									<h4>YOUR PAYMENT DETAILS</h4>
									<p><strong>IMPORTANT: On submission you will be directed to a secure payment area to enter credit card details.</strong></p>
									<p>A deposit of <strong><span id="deposit_currency"></span> $<span id="deposit"></span></strong> will be taken off your credit card to secure this booking.</p>
									<p><input type="checkbox" name="tc" id="tc" value="yes"/>
										<label for="tc">I have read and agree to the <a
											href="<?php echo $DS4->tc_url()?>"
											target="_blank">terms and conditions</a> and I am between 18-75 years of age.</label></p>
								</div>
								<div id="form-error-book-now" style="display:none"></div>
								<div class="book-now-button">
									<a href="/booking/step3.php" class="backbutton desktop">BACK</a>
									<input type="button" onclick="Step4.controller.book_now();" id="book_now_button" value="BOOK NOW"/>
									<a href="/booking/step3.php" class="backbutton mobile">BACK</a>
								</div>
							</div>
						</div>
						<input type="hidden" name="CustomerData" id="CustomerData" value="<?php echo htmlspecialchars($_SESSION["CustomerData"]);?>"/>
						<input type="hidden" name="ReservationRef" id="ReservationRef" value="<?php echo htmlspecialchars($_SESSION["ReservationRef"]);?>"/>
						<input type="hidden" name="ReservationNo" id="ReservationNo" value="<?php echo htmlspecialchars($_SESSION["ReservationNo"]);?>"/>
						<input type="hidden" name="total_deposit" value=""/>
					</form>
				</article>
				<aside>
					<script type="text/html" id="price_details_table_header_html">
						<tr>
							<th>Product</th>
							<th>Rental Days</th>
							<th>Daily Rate</th>
							<th>Total</th>
						</tr>
					</script>
					<script type="text/html" id="price_details_table_row_html">
						<tr class="%class">
							<td>%cell1 &nbsp;</td>
							<td>%cell2 &nbsp;</td>
							<td>%cell3 &nbsp;</td>
							<td>%cell4</td>
						</tr>
					</script>
					<script type="text/html" id="peoplegraphic_one_html">
						<div class="num-ppl">
							<img src="image/%no-people.png" alt="Persons" title="Persons"/>
						</div>
					</script>
					<script type="text/html" id="peoplegraphic_html">
						<div class="num-ppl">
							<img src="image/%nochildren-people.png" alt="Persons" title="Persons"/>
							<span>to</span>
							<img src="image/%noadults-people.png" alt="Persons" title="Persons"/>
						</div>
					</script>
					<script type="text/html" id="car_title_html">
						<h2><span class="main">%categoryfriendlydescription0</span></h2>
						<h3>%categoryfriendlydescription1</h3>
					</script>
					<script type="text/html" id="price_row_html">
						<tr>
							<th>%name</th>
							<td>%value</td>
							<td>$%total</td>
						</tr>
					</script>
				</aside> */ ?>
				
				<div class="row">
					
					<div id="content" class="content col-lg-8 col-md-8 col-sm-12 col-xs-12">
					
						<div class="inside">
						
							<form action="step5.php" method="post" id="frmStep4">
								<div id="guest" class="section">
									<h2>Guest Details</h2>
									<div class="form-group row">
										<label for="" class="col-sm-3 col-form-label">First Name:</label>
										<div class="col-sm-9">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-3 col-form-label">Last Name:</label>
										<div class="col-sm-9">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-3 col-form-label">Email:</label>
										<div class="col-sm-9">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-3 col-form-label">Phone:</label>
										<div class="col-sm-9">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-5 col-form-label">Number of people travelling:</label>
										<div class="col-sm-7">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-5 col-form-label">How did you hear about us?</label>
										<div class="col-sm-7">
											<select id="">
												<option value="">Online Booking</option>
												<option value="">Friend</option>
											</select>
										</div>
									</div>
								</div>
								<div id="disclaimer" class="section">
									<h2>Disclaimer</h2>
									<p><strong>IMPORTANT</strong></p>
									<p>By By clicking Book Now you will be directed to a secure payment area to enter credit card details.</p>

									<p>A deposit of <strong>$200.00</strong> will be taken off your credit card to secure this booking.</p>
									<span class="agreement"><input type="checkbox" /> I have read and agree to the Terms and Conditions and I am between 21-75 years of age.</span>
									<p class="text-center"><a class="back" href="#">Back</a><button class="btn btn-default">BOOK NOW!</button></p>
								</div>
								
								<input type="hidden" name="CustomerData" id="CustomerData" value="<?php echo htmlspecialchars($_SESSION["CustomerData"]);?>"/>
								<input type="hidden" name="ReservationRef" id="ReservationRef" value="<?php echo htmlspecialchars($_SESSION["ReservationRef"]);?>"/>
								<input type="hidden" name="ReservationNo" id="ReservationNo" value="<?php echo htmlspecialchars($_SESSION["ReservationNo"]);?>"/>
								<input type="hidden" name="total_deposit" value=""/>
							</form>
						</div>
					</div>
					
					<div id="sidebar" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
						<div id="itinerary" class="widget">
							<div class="widget-head">
								<h3>Your Itinerary</h3>
								<a href="#" class="modify">Modify Search</a>
							</div>
							<div class="widget-content">
								<span class="title">Pickup Location:</span> <span class="val">Las Vegas - Cherry Avenue North</span>
								<span class="title">Pickup Date & Time:</span> <span class="val">Wednesday, 30 June 13:00</span>
								<span class="title">Return Location:</span> <span class="val">Las Vegas - Cherry Avenue North</span>
								<span class="title">Return Date & Time:</span> <span class="val">Monday, 04 August 14:30</span>
								<span class="title">Youngest Driver:</span> <span class="val">21+ Years</span>
							</div>
						</div>
						
						<div id="cart" class="widget">
							<div class="widget-head row">
								<div class="col-xs-4">
									<span>Total:</span>
								</div>
								<div class="col-xs-8">
									<div class="pricing">
										<span class="curr-symbol">$</span><span class="price-num">1496</span><span class="small">.60</span><span class="curr-text">USD</span>
										<span class="tax">Incl Sales Tax: $119.98</span>
									</div>
								</div>
							</div>
							<div class="widget-content">
								<div class="vehicle-img">
									<img src="image/car1.png" />
								</div>
								<div class="cart-content">
									<a href="#" class="modify">Modify Search</a>
									<div class="section-wrap vehicle">
										<span class="section-title">Vehicle:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Maverick</span></div>
										</div>
									</div>
									<div class="section-wrap daily-rate">
										<span class="item-title">Daily Rate:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">13 days @ $89.62</span></div>
											<div class="col-xs-4"><span class="item-price">$1196.60</span></div>
										</div>
									</div>
									<div class="section-wrap mileage">
										<span class="item-title">Mileage:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">100 Miles p/day included</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
									</div>
									<div class="section-wrap extras">
										<span class="item-title">Extra Fees:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Free Extra Drivers (max. 4)</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Free Sleeping Gear</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Free Cooking equiptment and chairs</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
									</div>
									<div class="section-wrap insurance">
										<span class="item-title">Insurance:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">NO Worries Cover - Full Camper (CDW) and Liability (SLI) cover</span></div>
											<div class="col-xs-4"><span class="item-price">$289.25</span></div>
										</div>										
									</div>
									<div class="section-wrap tax">
										<span class="item-title">Insurance:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">$119.98</span></div>
											<div class="col-xs-4"><span class="item-price">$119.98</span></div>
										</div>										
									</div>
								</div>
							</div>
							<div class="deposit">
								<span class="deposit-title">Deposit Payable Now</span>
								<div class="pricing">
									<span class="curr-symbol">$</span><span class="price-num">200</span><span class="small">.00</span><span class="curr-text">USD</span>
								</div>
							</div>
						</div>
					</div>					
				</div>
			</div>
		</main>
		
		<?php echo Template::footer()?>
		
	</body>
</html>
