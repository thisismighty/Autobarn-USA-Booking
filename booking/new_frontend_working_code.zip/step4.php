<?php

require 'bin/required.php';
require 'etc/steps-conf.php';

$CDV=new ControllerDefaultValues();
$_SESSION=$CDV->step5($_SESSION,$_POST);

$DH=new DataHubspot();
$DH->step4($_COOKIE,$_SERVER,$_SESSION);

?><!DOCTYPE>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=0.8, maximum-scale=0.8, user-scalable=0"/>
		<script type="text/javascript">
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-2588665-<?php echo $CDV->anal($_SESSION['referrer'])?>', 'auto', {allowLinker: true});
ga('require', 'linker');
ga('linker:autoLink', ['travellers-autobarn.com.au', 'travellers-autobarn.fr', 'travellers-autobarn.it', 'travellers-autobarn.de', 'travellers-autobarn.nl'], false, true);
ga('send', 'pageview');
		</script>
		<?php echo ViewCSS::draw('bootstrap.min.css');?>
		<?php echo ViewCSS::draw('font-awesome.min.css');?>
		<?php echo ViewCSS::draw('body.css');?>
		<?php echo ViewCSS::draw('nav.css');?>
		<?php echo ViewCSS::draw('step5.css');?>
		<?php echo ViewCSS::draw('style-v7.css');?>
		<?php echo ViewJS::draw('jquery-2.1.3.min.js');?>
		<?php echo ViewJS::draw('bootstrap.min.js');?>
		<?php echo ViewJS::draw('Template.js');?>
		<?php echo ViewJS::draw('Select.js');?>
		<?php echo ViewJS::draw('Log.js');?>
		<?php echo ViewJS::draw('View.js');?>
		<?php echo ViewJS::draw('Controller.js');?>
		<script src="<?php echo ControllerSourceSite::api_url_get()?>" type="text/javascript"></script>
		<?php echo ViewJS::draw('Step5.js');?>
		<script type="text/javascript">
			Step5.data=<?php echo json_encode($_SESSION)?>;
			$(function(){
				$('a.modify').on('click', function(){
					$('#search-form').slideDown(400);
					$("html, body").animate({ scrollTop: $('#search-form').offset().top }, 1000);
					return false;
				});
				$('#search-form .close').on('click', function(){
					$('#search-form').slideUp(400);
				});
			});
		</script>
		<?php echo $CDV->remarketing_code(); ?>
	</head>
	<body>
		<?php echo Template::header(ViewNav::step5())?>
		<main>
			<div class="container">
				<article>
					<form id="search-form" method="post" action="step3.php" style="display:none;">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<h2>Modify Your Search
								<a class="close">Close <i class="fa fa-remove"></i></a>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="form-group row">
									<label for="PickupLocationID" class="col-sm-4 col-form-label">Pick up location*</label>
									<div class="col-sm-8">
										<select name="PickupLocationID" id="PickupLocationID">
											<option value="<?php echo htmlspecialchars($_SESSION['PickupLocationID'])?>">Loading...</option>
										</select>
									</div>
								</div>
								
								<div class="form-group row">
									<label for="DropOffLocationID" class="col-sm-4 col-form-label">Return location*</label>
									<div class="col-sm-8">
										<select name="DropOffLocationID" id="DropOffLocationID">
											<option value="<?php echo htmlspecialchars($_SESSION['DropOffLocationID'])?>">Loading...</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">								
								
								<div class="row">
									<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<label for="PickupDate" class="col-sm-6 col-form-label">Date & time:</label>
											<div class="col-sm-6">
												<input type="text" name="PickupDate" id="PickupDate" value="<?php echo htmlspecialchars($_SESSION['PickupDate'])?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<div class="col-sm-12">
												<select id="PickupTime" name="PickupTime">
													<option value="<?php echo htmlspecialchars($_SESSION['PickupTime'])?>">Time</option>
													<option value="01:00:00">01:00</option>
													<option value="02:00:00">02:00</option>
													<option value="03:00:00">03:00</option>
													<option value="04:00:00">04:00</option>
													<option value="05:00:00">05:00</option>
													<option value="06:00:00">06:00</option>
													<option value="07:00:00">07:00</option>
													<option value="08:00:00">08:00</option>
													<option value="09:00:00">09:00</option>
													<option value="10:00:00">10:00</option>
													<option value="11:00:00">11:00</option>
													<option value="12:00:00">12:00</option>
													<option value="13:00:00">13:00</option>
													<option value="14:00:00">14:00</option>
													<option value="15:00:00">15:00</option>
													<option value="16:00:00">16:00</option>
													<option value="17:00:00">17:00</option>
													<option value="18:00:00">18:00</option>
													<option value="19:00:00">19:00</option>
													<option value="20:00:00">20:00</option>
													<option value="21:00:00">21:00</option>
													<option value="22:00:00">22:00</option>
													<option value="23:00:00">23:00</option>
													<option value="24:00:00">24:00</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<label for="ReturnDate" class="col-sm-6 col-form-label">Date & time:</label>
											<div class="col-sm-6">
												<input type="text" name="ReturnDate" id="ReturnDate" value="<?php echo htmlspecialchars($_SESSION['ReturnDate'])?>"/>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">	
										<div class="form-group row">
											<div class="col-sm-12">
												<select id="ReturnTime" name="ReturnTime">
													<option value="<?php echo htmlspecialchars($_SESSION['ReturnTime'])?>">Time</option>
													<option value="01:00:00">01:00</option>
													<option value="02:00:00">02:00</option>
													<option value="03:00:00">03:00</option>
													<option value="04:00:00">04:00</option>
													<option value="05:00:00">05:00</option>
													<option value="06:00:00">06:00</option>
													<option value="07:00:00">07:00</option>
													<option value="08:00:00">08:00</option>
													<option value="09:00:00">09:00</option>
													<option value="10:00:00">10:00</option>
													<option value="11:00:00">11:00</option>
													<option value="12:00:00">12:00</option>
													<option value="13:00:00">13:00</option>
													<option value="14:00:00">14:00</option>
													<option value="15:00:00">15:00</option>
													<option value="16:00:00">16:00</option>
													<option value="17:00:00">17:00</option>
													<option value="18:00:00">18:00</option>
													<option value="19:00:00">19:00</option>
													<option value="20:00:00">20:00</option>
													<option value="21:00:00">21:00</option>
													<option value="22:00:00">22:00</option>
													<option value="23:00:00">23:00</option>
													<option value="24:00:00">24:00</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group row">
											<label for="DriverAge" class="col-sm-5 col-form-label">Driver's age</label>
											<div class="col-sm-7">
												<select name="DriverAge" id="DriverAge">
													<option value="">21 + min</option>
													<option value="">21+</option>
													<option value="">25+</option>
													<option value="">30+</option>
													<option value="">35+</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
										<div class="form-group row">
											<label for="PromotionalCode" class="col-sm-6 col-form-label">Promotional Code:</label>
											<div class="col-sm-6">
												<input type="text" name="PromotionalCode" id="PromotionalCode" value=""/>
											</div>
										</div>
									</div>
									<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
										<div class="row">
											<div class="col-lg-12 col-md-12s col-sm-12 col-xs-12">
												<div id="update-search" class="btn btn-default" onclick="Step2.controller.start_live()" style="display:none;">
													<img src="image/preview-full-loading.gif" style="visibility:hidden;" />
													<span class="">UPDATE SEARCH</span>
													<img src="image/preview-full-loading.gif" />
												</div>
												<div id="change-search" class="btn btn-default" onclick="Step2.controller.change_search()">
													CHANGE SEARCH
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
							<input type="hidden" name="CarSizeID" value=""/>
							<input type="hidden" name="PickupLocation_name" value=""/>
							<input type="hidden" name="DropOffLocation_name" value=""/>
							<input type="hidden" name="CategoryType_name" value=""/>
							<input type="hidden" name="CategoryType_vehicledescurl" value=""/>
							<input type="hidden" name="CategoryType_imagename" value=""/>
							<input type="hidden" name="price_table_html" value=""/>						
						</div>
					</form>
					<div id="form-error" style="display:none"></div>
				</article>
				<?php /*
				<article>
					<div class="row">
						<h2>Secure Credit Card Payment</h2>
						<img src="image/visa_mastercard.jpg" alt="visa/mastercard" title="visa/mastercard" width="200"/>
					</div>
					<iframe id="frmAuric" name="frmAuric" src="about:blank" frameborder="0"></iframe>
					<div class="row">
						<div>
							<img src="image/Auric.png" alt="Auric" title="Auric" />
							<div>Secured by www.auricsystems.com</div>
							<div>Auric Systems is a Level 1 PCI DSS Validated Service Provider.</div>
						</div>
						<img src="image/pci_dss.png" alt="PCI DSS" title="PCI DSS" />
					</div>
				</article>
				<aside>
				</aside> */ ?>
				<div class="row">
					
					<div id="content" class="content col-lg-8 col-md-8 col-sm-12 col-xs-12">
					
						<div class="inside">
						
							<form action="step6.php" method="post" id="frmStep5">
								<div id="payment" class="section">
									<h2>Payment</h2>
									<div class="form-group row">
										<label for="" class="col-sm-4 col-form-label">Card Type:</label>
										<div class="col-sm-8">
											<select id="">
												<option value="">Credit Card: Visa</option>
												<option value="">Credit Card: Mastercard</option>
											</select>
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-4 col-form-label">Payment Type:</label>
										<div class="col-sm-8">
											<select id="">
												<option value="">Deposit Only</option>
												<option value="">Pickup</option>
											</select>
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-4 col-form-label">Card Number:</label>
										<div class="col-sm-8">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-4 col-form-label">Card Expiry:</label>
										<div class="col-sm-8">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-4 col-form-label">Card Holder Name:</label>
										<div class="col-sm-8">
											<input id="" type="text" />
										</div>
									</div>
									<div class="form-group row">
										<label for="" class="col-sm-4 col-form-label">CVV:</label>
										<div class="col-sm-8">
											<input id="" type="text" />
										</div>
									</div>
									
									<div class="deposit row">
										<div class="col-sm-8 col-xs-6">Pay Deposit Only:</div>
										<div class="col-sm-4 col-xs-6"><span class="curr-symbol">$</span><span class="price">200</span><span class="small-num">.00</span><span class="curr-text">USD</spaN></div>
									</div>
									
									<div class="pickup row">
										<div class="col-sm-8 col-xs-6">Amount Due on Pick Up:</div>
										<div class="col-sm-4 col-xs-6"><span class="curr-symbol">$</span><span class="price">1050</span><span class="small-num">.00</span><span class="curr-text">USD</spaN></div>
									</div>
									
									<p class="text-center"><a class="back" href="#">Back</a><button class="btn btn-default">PAY NOW!</button></p>
								</div>
								<div id="guest-details" class="guest-fields section">
									<h2>Guest Details</h2>
									<div class="row">
										<span class="field col-xs-5">First Name:</span><span class="value col-xs-7">Bella</span>
										<span class="field col-xs-5">Last Name:</span><span class="value col-xs-7">Lamshed</span>
										<span class="field col-xs-5">Phone:</span><span class="value col-xs-7">+1 652 736 8663</span>
										<span class="field col-xs-5">Email:</span><span class="value col-xs-7">bella@thisismighty.com</span>									
									</div>
								</div>
							</form>
						</div>
					</div>
					
					<div id="sidebar" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
						<div id="itinerary" class="widget">
							<div class="widget-head">
								<h3>Your Itinerary</h3>
								<a href="#" class="modify">Modify Search</a>
							</div>
							<div class="widget-content">
								<span class="title">Pickup Location:</span> <span class="val">Las Vegas - Cherry Avenue North</span>
								<span class="title">Pickup Date & Time:</span> <span class="val">Wednesday, 30 June 13:00</span>
								<span class="title">Return Location:</span> <span class="val">Las Vegas - Cherry Avenue North</span>
								<span class="title">Return Date & Time:</span> <span class="val">Monday, 04 August 14:30</span>
								<span class="title">Youngest Driver:</span> <span class="val">21+ Years</span>
							</div>
						</div>
						
						<div id="cart" class="widget">
							<div class="widget-head row">
								<div class="col-xs-4">
									<span>Total:</span>
								</div>
								<div class="col-xs-8">
									<div class="pricing">
										<span class="curr-symbol">$</span><span class="price-num">1496</span><span class="small">.60</span><span class="curr-text">USD</span>
										<span class="tax">Incl Sales Tax: $119.98</span>
									</div>
								</div>
							</div>
							<div class="widget-content">
								<div class="vehicle-img">
									<img src="image/car1.png" />
								</div>
								<div class="cart-content">
									<a href="#" class="modify">Modify Search</a>
									<div class="section-wrap vehicle">
										<span class="section-title">Vehicle:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Maverick</span></div>
										</div>
									</div>
									<div class="section-wrap daily-rate">
										<span class="item-title">Daily Rate:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">13 days @ $89.62</span></div>
											<div class="col-xs-4"><span class="item-price">$1196.60</span></div>
										</div>
									</div>
									<div class="section-wrap mileage">
										<span class="item-title">Mileage:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">100 Miles p/day included</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
									</div>
									<div class="section-wrap extras">
										<span class="item-title">Extra Fees:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Free Extra Drivers (max. 4)</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Free Sleeping Gear</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">Free Cooking equiptment and chairs</span></div>
											<div class="col-xs-4"><span class="item-price">$0.00</span></div>
										</div>										
									</div>
									<div class="section-wrap insurance">
										<span class="item-title">Insurance:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">NO Worries Cover - Full Camper (CDW) and Liability (SLI) cover</span></div>
											<div class="col-xs-4"><span class="item-price">$289.25</span></div>
										</div>										
									</div>
									<div class="section-wrap tax">
										<span class="item-title">Insurance:</span>
										<div class="items row">
											<div class="col-xs-8"><span class="item-name">$119.98</span></div>
											<div class="col-xs-4"><span class="item-price">$119.98</span></div>
										</div>										
									</div>
								</div>
							</div>
							<div class="deposit">
								<span class="deposit-title">Deposit Payable Now</span>
								<div class="pricing">
									<span class="curr-symbol">$</span><span class="price-num">200</span><span class="small">.00</span><span class="curr-text">USD</span>
								</div>
							</div>
						</div>
					</div>					
				</div>
			</div>
		</main>
		
		<?php echo Template::footer()?>
		
	</body>
</html>
